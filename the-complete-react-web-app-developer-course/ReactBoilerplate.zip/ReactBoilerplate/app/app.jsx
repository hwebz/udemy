var React = require('react');
var ReactDOM = require('react-dom');

ReactDOM.render(
	<h1>React Boilerplace</h1>,
	document.getElementById('app')
)